﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module2HW1
{
    internal enum LogType
    {
        Undefined = 0,
        Error,
        Info,
        Warning
    }
}
